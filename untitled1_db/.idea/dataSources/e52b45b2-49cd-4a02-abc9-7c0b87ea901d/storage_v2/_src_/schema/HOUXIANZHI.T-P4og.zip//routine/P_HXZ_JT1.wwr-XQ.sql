create procedure p_hxz_jt1(bm in varchar2,dt in date) is
v_selectsql varchar2(200);
v_count number(9);
begin
  v_selectsql:='select count(*) from '||bm||' where 更新日期>='||dt||'-1 and 更新日期<date'||dt||' and 是否有文本记录=1';

execute immediate v_selectsql into v_count;
dbms_output.put_line('总数是：'||v_count);
--dbms_output.put_line(v_selectsql);
end;
/

