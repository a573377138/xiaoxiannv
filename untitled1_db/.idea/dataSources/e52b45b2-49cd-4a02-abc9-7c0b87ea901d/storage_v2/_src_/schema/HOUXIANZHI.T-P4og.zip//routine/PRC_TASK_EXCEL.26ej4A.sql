create procedure PRC_TASK_EXCEL is
--out_file    utl_file.file_type; --定义一个文件类型
   --v_begindate varchar2(23);
  --v_enddate   varchar2(23);
begin
  --v_begindate := '2017-11-03 16:00:00';
  --v_enddate   := '2017-11-03 16:03:00';
  out_file    := utl_file.fopen('DIR_EXCEL', 'ceshi.xlsx', 'W');
  --抬头
  utl_file.put(out_file, 'name' || chr(9));
  utl_file.put(out_file, 'job' || chr(9));
  utl_file.put_line(out_file, '');

  for o in (select name || chr(9) vin,job || chr(9) autoid
              from scott
             ) loop
    utl_file.putf(out_file, o.vin);
    utl_file.put(out_file, o.autoid);
    --utl_file.put(out_file, convert('中国人', 'ZHS16GBK'));--汉子时转化字符格式，解决汉子乱码
    utl_file.put_line(out_file, '');
  end loop;
  utl_file.fflush(out_file);
  utl_file.fclose(out_file); --关闭文件流

  --处理异常
exception
  when others then
    rollback;
    prc_log_new(SYSDATE, 'error');
  utl_file.fclose(out_file); --关闭文件流，防止异常关闭
end PRC_TASK_EXCEL;
/

