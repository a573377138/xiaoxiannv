create trigger TRIGGER_PRODUCT_ID
  before insert
  on PRODUCT
  for each row
  when (new.id is null)
begin
  select seq_product_id.nextval into :new.id from dual;
end;
/

