create trigger TRIGGER_PRODUCT_COST_ID
  before insert
  on PRODUCT_COST
  for each row
  when (new.id is null)
begin
  select seq_product_cost_id.nextval into :new.id from dual;
end;
/

