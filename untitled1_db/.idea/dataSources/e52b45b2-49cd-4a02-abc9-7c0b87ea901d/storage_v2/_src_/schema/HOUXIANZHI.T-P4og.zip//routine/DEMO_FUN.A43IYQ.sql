create FUNCTION demo_fun(

  Name VARCHAR2,--注意VARCHAR2不能给精度，如：VARCHAR2(10)，其它类似

  Age INTEGER,

  Sex VARCHAR2)

  RETURN VARCHAR2

AS

  V_var VARCHAR2(32);

BEGIN

  V_var := name||'：'||TO_CHAR(age)||'岁.'||sex;

  RETURN v_var;

END;
/

