create procedure hxz_bd(variable v_bl number) as


begin
  select * from employee where emp_id =:v_bl;
end;
/

