create trigger RENWU1T_ID_P
  before insert
  on RENWU1
  for each row
BEGIN
SELECT  renwu1t_Id_P.nextval INTO :new.id FROM dual;
END;
/

