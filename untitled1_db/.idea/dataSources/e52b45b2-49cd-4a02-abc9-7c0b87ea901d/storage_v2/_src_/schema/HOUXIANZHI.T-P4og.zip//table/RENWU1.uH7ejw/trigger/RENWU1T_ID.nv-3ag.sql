create trigger RENWU1T_ID
  before insert
  on RENWU1
  for each row
BEGIN
SELECT  renwu1t_id.nextval INTO :new.id FROM dual;
END;
/

