create procedure p_test as
begin
insert into test001 values(sysdate);
end;
/

