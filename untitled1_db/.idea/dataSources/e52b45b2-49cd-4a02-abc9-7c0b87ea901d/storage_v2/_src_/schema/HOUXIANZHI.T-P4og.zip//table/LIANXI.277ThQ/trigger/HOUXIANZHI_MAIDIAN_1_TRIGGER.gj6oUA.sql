create trigger HOUXIANZHI_MAIDIAN_1_TRIGGER
  before insert
  on LIANXI
  for each row
begin
select book_seq.nextval into :new.bookId from dual;
end ;
/

