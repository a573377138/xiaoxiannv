create trigger TRIGGER_ADEMO_ID
  before insert
  on ADEMO
  for each row
  when (new.id is null)
begin
  select seq_ademo_id.nextval into :new.id from dual;
end;
/

