create PACKAGE MANAGE_EMP_PKG
AS
  --增加一名员工
  FUNCTION hire_emp
    (ename VARCHAR2, job VARCHAR2
    , mgr NUMBER, sal NUMBER
    , comm NUMBER, deptno NUMBER)
  RETURN NUMBER;

  --新增一个部门
  FUNCTION add_dept(dname VARCHAR2, loc VARCHAR2)
  RETURN NUMBER;

  --删除指定员工
  PROCEDURE remove_emp(empno NUMBER);
  --删除指定部门
  PROCEDURE remove_dept(deptno NUMBER);
  --增加指定员工的工资
  PROCEDURE increase_sal(empno NUMBER, sal_incr NUMBER);
  --增加指定员工的奖金
  PROCEDURE increase_comm(empno NUMBER, comm_incr NUMBER);
END MANAGE_EMP_PKG;
/

