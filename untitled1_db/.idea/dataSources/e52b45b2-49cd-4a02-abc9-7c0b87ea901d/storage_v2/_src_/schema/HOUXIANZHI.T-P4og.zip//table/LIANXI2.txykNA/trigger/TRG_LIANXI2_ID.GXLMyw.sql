create trigger TRG_LIANXI2_ID
  before insert
  on LIANXI2
  for each row
BEGIN
SELECT  seq_lianxi2_id.nextval INTO :new.id FROM dual;
END;
/

