create procedure cccc(
v_empno varchar2(20)%scott.emp.empno%type)
as
v_empno varchar2(20)
begin
  select empno into v_empno from scott.emp where ename='hxz';
  dbms_output.put.line('编号为：'||v_empno);
  /

