create PACKAGE BODY MANAGE_EMP_PKG
AS
    total_emps  NUMBER; --员工数
    total_depts NUMBER; --部门数
    no_sal    EXCEPTION;
    no_comm   EXCEPTION;
  --增加一名员工
  FUNCTION hire_emp(ename VARCHAR2, job VARCHAR2, mgr NUMBER,
                       sal NUMBER, comm NUMBER, deptno NUMBER)
  RETURN NUMBER  --返回新增加的员工编号
  IS
    new_empno NUMBER(4);
  BEGIN
SELECT empseq.NEXTVAL INTO new_empno FROM dual;
SELECT COUNT(*) INTO total_emps FROM scott.emp;--当前记录总数

    INSERT INTO scott.emp
    VALUES (new_empno, ename, job, mgr, sysdate, sal, comm, deptno);
    total_emps:=total_emps+1;
  RETURN(new_empno);
  EXCEPTION
     WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('温馨提示:发生系统错误!');
  END hire_emp;

  --新增一个部门
  FUNCTION add_dept(dname VARCHAR2, loc VARCHAR2)
  RETURN NUMBER
  IS
    new_deptno NUMBER(4); --部门编号
  BEGIN
    --得到一个新的自增的员工编号
    SELECT deptseq.NEXTVAL INTO new_deptno FROM dual;
    SELECT COUNT(*) INTO total_depts FROM scott.dept;--当前部门总数
    INSERT INTO scott.dept VALUES (new_deptno, dname, loc);
    total_depts:=total_depts;
  RETURN(new_deptno);
  EXCEPTION
     WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('温馨提示:发生系统错误!');
  END add_dept;

  --删除指定员工
  PROCEDURE remove_emp(empno NUMBER)
  IS
    no_result EXCEPTION; --自定义异常
  BEGIN
    DELETE FROM scott.emp WHERE scott.emp.empno=remove_emp.empno;
    IF SQL%NOTFOUND THEN
        RAISE no_result;
    END IF;
    total_emps:=total_emps - 1; --总的员工数减1
  EXCEPTION
     WHEN no_result THEN
        DBMS_OUTPUT.PUT_LINE('温馨提示:你需要的数据不存在!');
     WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('温馨提示:发生系统错误!');
  END remove_emp;

  --删除指定部门
  PROCEDURE remove_dept(deptno NUMBER)
  IS
     no_result EXCEPTION; --自定义异常
     exception_deptno_remaining EXCEPTION; --自定义异常
     /*-2292 是违反一致性约束的错误代码*/
     PRAGMA EXCEPTION_INIT(exception_deptno_remaining, -2292);
  BEGIN
    DELETE FROM scott.dept WHERE scott.dept.deptno=remove_dept.deptno;

    IF SQL%NOTFOUND THEN
        RAISE no_result;
    END IF;
    total_depts:=total_depts-1; --总的部门数减1
  EXCEPTION
     WHEN no_result THEN
        DBMS_OUTPUT.PUT_LINE('温馨提示:你需要的数据不存在!');
     WHEN exception_deptno_remaining THEN
        DBMS_OUTPUT.PUT_LINE('温馨提示:违反数据完整性约束!');
     WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('温馨提示:发生系统错误!');
  END remove_dept;

  --给指定员工增加指定数量的工资
  PROCEDURE increase_sal(empno NUMBER, sal_incr NUMBER)
  IS
    curr_sal NUMBER(7, 2); --当前工资
  BEGIN
    --得到当前工资
    SELECT sal INTO curr_sal FROM scott.emp WHERE scott.emp.empno=increase_sal.empno;

    IF curr_sal IS NULL THEN
       RAISE no_sal;
    ELSE
       UPDATE scott.emp SET sal = sal + increase_sal.sal_incr --当前工资加新增的工资
       WHERE scott.emp.empno = increase_sal.empno;
    END IF;
    EXCEPTION
       WHEN NO_DATA_FOUND THEN
          DBMS_OUTPUT.PUT_LINE('温馨提示:你需要的数据不存在!');
       WHEN no_sal THEN
          DBMS_OUTPUT.PUT_LINE('温馨提示:此员工的工资不存在!');
       WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE('温馨提示:发生系统错误!');
  END increase_sal;

  --给指定员工增加指定数量的奖金
  PROCEDURE increase_comm(empno NUMBER, comm_incr NUMBER)
  IS
    curr_comm NUMBER(7,2);
  BEGIN
    --得到指定员工的当前资金
    SELECT comm INTO curr_comm
    FROM scott.emp WHERE scott.emp.empno = increase_comm.empno;

    IF curr_comm IS NULL THEN
       RAISE no_comm;
    ELSE
      UPDATE scott.emp SET comm = comm + increase_comm.comm_incr
      WHERE scott.emp.empno=increase_comm.empno;
    END IF;
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('温馨提示:你需要的数据不存在!');
     WHEN no_comm THEN
        DBMS_OUTPUT.PUT_LINE('温馨提示:此员工的奖金不存在!');
     WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('温馨提示:发生系统错误!');
  END increase_comm;
END MANAGE_EMP_PKG;--创建包体结束
/

